
"""Simple data pipeline: load csv, basic validation, preprocessing functions."""
from typing import Tuple
import pandas as pd
import numpy as np

def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df

def validate_schema(df: pd.DataFrame) -> bool:
    expected = {'customer_id','tenure_months','plan_type','monthly_fee','usage_minutes','num_support_calls','contract_type','payment_method','last_active_days_ago','churned'}
    return expected.issubset(set(df.columns))

def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # basic feature engineering consistent with notebooks
    df['is_premium'] = (df.plan_type=='premium').astype(int)
    df['support_calls_per_month'] = df.num_support_calls / df.tenure_months.replace(0,1)
    df['recent_activity_flag'] = (df.last_active_days_ago <= 14).astype(int)
    # one-hot simple
    df = pd.get_dummies(df, columns=['plan_type','contract_type','payment_method'], drop_first=True)
    return df
