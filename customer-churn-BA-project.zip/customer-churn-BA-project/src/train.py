
"""Train a RandomForest model on features and save model + metrics to artifacts/"""
import argparse, json, os, pickle
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score, confusion_matrix
from data_pipeline import load_data, validate_schema, preprocess

def main(args):
    df = load_data(args.data)
    assert validate_schema(df), "Schema validation failed"
    df = preprocess(df)
    X = df.drop(columns=['customer_id','churned'])
    y = df['churned']
    X_train, X_test, y_train, y_test = train_test_split(X,y,stratify=y,test_size=0.2,random_state=42)
    model = RandomForestClassifier(n_estimators=50, random_state=42)
    model.fit(X_train, y_train)
    probs = model.predict_proba(X_test)[:,1]
    preds = (probs >= 0.5).astype(int)
    metrics = {
        'roc_auc': float(roc_auc_score(y_test, probs)),
        'precision': float(precision_score(y_test, preds)),
        'recall': float(recall_score(y_test, preds)),
        'f1': float(f1_score(y_test, preds))
    }
    os.makedirs(args.output, exist_ok=True)
    with open(os.path.join(args.output, 'model.pkl'), 'wb') as f:
        pickle.dump(model, f)
    with open(os.path.join(args.output, 'metrics.json'), 'w') as f:
        json.dump(metrics, f, indent=2)
    # sample predictions file
    sample = X_test.copy()
    sample['probability'] = probs
    sample['prediction'] = preds
    sample['customer_id'] = df.loc[X_test.index, 'customer_id']
    sample[['customer_id','probability','prediction']].to_csv(os.path.join(args.output, 'sample_predictions.csv'), index=False)
    print('Training completed. Metrics saved to', os.path.join(args.output, 'metrics.json'))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    main(args)
