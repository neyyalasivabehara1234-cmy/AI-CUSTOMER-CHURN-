
"""Load model and predict on input CSV, write predictions CSV."""
import argparse, os, pickle
import pandas as pd
from data_pipeline import load_data, preprocess

def main(args):
    df = load_data(args.input)
    ids = df['customer_id']
    df_proc = preprocess(df)
    X = df_proc.drop(columns=['customer_id','churned']) if 'churned' in df_proc.columns else df_proc.drop(columns=['customer_id'])
    with open(args.model, 'rb') as f:
        model = pickle.load(f)
    probs = model.predict_proba(X)[:,1]
    preds = (probs >= 0.5).astype(int)
    out = pd.DataFrame({'customer_id': ids, 'probability': probs, 'prediction': preds})
    os.makedirs(args.output_dir, exist_ok=True)
    out.to_csv(os.path.join(args.output_dir, args.output_file), index=False)
    print('Predictions saved to', os.path.join(args.output_dir, args.output_file))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output_dir', required=True)
    parser.add_argument('--output_file', default='predictions.csv')
    args = parser.parse_args()
    main(args)
