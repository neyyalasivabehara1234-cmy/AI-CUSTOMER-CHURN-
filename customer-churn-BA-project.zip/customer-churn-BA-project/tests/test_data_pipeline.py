
from src.data_pipeline import load_data, validate_schema, preprocess
import os
def test_load_and_validate():
    p = os.path.join('data','churn_dataset.csv')
    df = load_data(p)
    assert validate_schema(df)
def test_preprocess_columns():
    df = load_data(os.path.join('data','churn_dataset.csv'))
    dproc = preprocess(df)
    assert 'is_premium' in dproc.columns
