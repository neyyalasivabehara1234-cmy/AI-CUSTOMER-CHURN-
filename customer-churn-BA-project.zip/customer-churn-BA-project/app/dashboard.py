
import streamlit as st
import pandas as pd, pickle, os
st.set_page_config(page_title='Churn Dashboard', layout='wide')
st.title('Customer Churn Dashboard - Demo')

data_path = os.path.join('data', 'churn_dataset.csv')
st.sidebar.header('Actions')
if st.sidebar.button('Load default data'):
    df = pd.read_csv(data_path)
    st.write('Sample data (first 5 rows):')
    st.dataframe(df.head())
    st.metric('Total customers', len(df))
    st.metric('Churn rate', f"{df.churned.mean():.2%}")
    st.metric('Avg tenure (months)', f"{df.tenure_months.mean():.1f}")
    st.subheader('Churn distribution by plan_type')
    st.bar_chart(df.groupby('plan_type')['churned'].mean())
st.sidebar.header('Predict')
uploaded = st.sidebar.file_uploader('Upload CSV for prediction', type=['csv'])
if uploaded is not None:
    df_in = pd.read_csv(uploaded)
    st.write('Uploaded sample:')
    st.dataframe(df_in.head())
    # Load model
    model_path = os.path.join('artifacts','model.pkl')
    if os.path.exists(model_path):
        model = pickle.load(open(model_path,'rb'))
        st.success('Model loaded from artifacts/model.pkl')
        # Minimal preprocessing: assume pipeline consistent
        df_proc = df_in.copy()
        df_proc = pd.get_dummies(df_proc, columns=['plan_type','contract_type','payment_method'], drop_first=True)
        # align columns
        # naive: select numeric cols only for demo
        X = df_proc.select_dtypes(include=['number']).drop(columns=['churned'], errors='ignore')
        preds = model.predict_proba(X)[:,1]
        out = df_in[['customer_id']].copy()
        out['probability'] = preds
        out['prediction'] = (preds >= 0.5).astype(int)
        st.write(out.head())
        st.download_button('Download predictions CSV', out.to_csv(index=False), file_name='predictions.csv')
    else:
        st.error('No model found in artifacts/ - run training first.')
